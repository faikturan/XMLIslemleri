package jdomparser;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;

public class XmlReader2 {

	public static void main(String[] args) {
		SAXBuilder builder = new SAXBuilder();
		try {
			Document xml = builder.build(new File("ogrenci.xml"));
			Element root = xml.getRootElement();
			System.out.println("XML in root element: " +root.getName());
			System.out.println("XML de kay�tl� ki�i say�s�: " + root.getChildren().size());
			List<Element> ogrenciler = root.getChildren();
			Iterator<Element> itr = ogrenciler.iterator();
			while (itr.hasNext()) {
				Element ogrenci = itr.next();
				System.out.println(ogrenci.getName() + ":");
				System.out.println("No: " +ogrenci.getAttributeValue("no"));
				System.out.println("ad : " + ogrenci.getChildText("ad"));
				System.out.println("soyad : " + ogrenci.getChildText("soyad"));
			}
		} catch (JDOMException | IOException e) {
			e.printStackTrace();
		}

	}

}
