package jdomparser;

public class XmlReader {

	public static void main(String[] args) {
		

	}

}
