package marshallingSample;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

public class OgrenciObject2Xml {

	public static void main(String[] args) {
		Ogrenci ogrenci = new Ogrenci();
		ogrenci.setAd("faik");
		ogrenci.setSoyad("turan");
		ogrenci.setDers("fizik");
		ogrenci.setNo(5);
		ogrenci.setBabaAd("arif");
		try {
			FileWriter writer = new FileWriter(new File("ogrenci.xml"));
			JAXBContext jc = JAXBContext.newInstance(Ogrenci.class);
			Marshaller marshaller = jc.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			marshaller.marshal(ogrenci, writer);
			marshaller.marshal(ogrenci, System.out);
		} catch (IOException | JAXBException e) {
			e.printStackTrace();
		}

	}

}
